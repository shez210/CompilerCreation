import java.io.IOException;
/**
 * @Author Shehriyar Faisal
 * 33869774
 */
public class SyntaxAnalyser extends AbstractSyntaxAnalyser {

    private String filename;
    /**
     * This is a method for linking the filename to the Syntax and Lexical analyser. Passes in the file
     * @param fileName
     */
    public SyntaxAnalyser(String fileName) {
        try{
            lex = new LexicalAnalyser(fileName);
            this.filename = fileName;
        }catch(Exception e){
            System.out.println("Error: File Not Found " + fileName);
        }
    }
    /**
     * This method is for the Statement Part of the analysis
     * Statement part needs the statementlist
     * @throws IOException
     * @throws CompilationException
     */
    @Override
    public void _statementPart_() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("StatementPart");
            acceptTerminal(Token.beginSymbol);
            getStatementList();

            acceptTerminal(Token.endSymbol);
            myGenerate.finishNonterminal("StatementPart");
            if(nextToken.symbol != Token.eofSymbol){
                myGenerate.reportError(nextToken,
                        "Error:[File:\"" + filename + "\"] [On Line :" + nextToken.lineNumber + "]" +
                                "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                " Expecting: " + Token.getName(Token.eofSymbol));
            }

        }catch (CompilationException  e){
            throw new CompilationException ("Compilation Exception: Error Parsing In <STATEMENT PART> On Line Number " + nextToken.lineNumber, e);
            }
        }
    /**
     * Checks to see if current symbol is valid and points to next token/symbol
     * @param symbol
     * @throws IOException
     * @throws CompilationException
     */
    @Override
    public void acceptTerminal(int symbol) throws IOException, CompilationException {

            if (nextToken.symbol == symbol) {//checks to see if next token is valid in the symbolTable

                myGenerate.insertTerminal(nextToken); //insert it, then look ahead
                nextToken = lex.getNextToken();//get the next token
            } else {
                myGenerate.reportError(nextToken,
                        "Error:[File:\"" + filename + "\"] [On Line :" + nextToken.lineNumber + "]" +
                                "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                " Expecting: " + Token.getName(symbol)
                );
            }
        }

    /**
     * Method for the StaementList. Checks for basic functions such as a semi-colon
     * @throws IOException
     * @throws CompilationException
     */
    void getStatementList() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("StatementList");

            getStatement();//go to the range of statements

            while (nextToken.symbol == Token.semicolonSymbol) {//basic check to see if statement has semi colon, expect another statement
                acceptTerminal(Token.semicolonSymbol);
                getStatement();
            }

            myGenerate.finishNonterminal("StatementList");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <STATEMENT LIST> on Line number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Checks to see if next symbol matches one of the statements
     * @throws IOException
     * @throws CompilationException
     */
    void getStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("Statement");

            switch (nextToken.symbol) {
                case Token.callSymbol:
                    procedureStatement();
                    break;
                case Token.identifier:
                    assignmentStatement();
                    break;
                case Token.ifSymbol:
                    ifStatement();
                    break;
                case Token.whileSymbol:
                    whileStatement();
                    break;
                case Token.doSymbol:
                    untilStatement();
                    break;
                case Token.forSymbol:
                    forStatement();
                    break;
                default:
                    myGenerate.reportError(nextToken,
                            "Error:[File:\"" + filename + "\"] [On Line:" + nextToken.lineNumber + "]" +
                                    "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                    " Expecting: In Statement " +
                                    " (" + Token.getName(Token.ifSymbol) +
                                    " ," + Token.getName(Token.whileSymbol) +
                                    " ," + Token.getName(Token.callSymbol) +
                                    " ," + Token.getName(Token.doSymbol) +
                                    " ," + Token.getName(Token.identifier) + ")"
                    );
            }
            myGenerate.finishNonterminal("Statement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Method for the Procedure Statement, accepts and checks the call symbol, identifier, left parenthesis, args and right par
     * @throws IOException
     * @throws CompilationException
     */
    void procedureStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("ProcedureStatement");

            acceptTerminal(Token.callSymbol);
            acceptTerminal(Token.identifier);
            acceptTerminal(Token.leftParenthesis);

            argumentsList();//goes to args list

            acceptTerminal(Token.rightParenthesis);
            myGenerate.finishNonterminal("ProcedureStatement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <PROCEDURE STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Arguments list method, used by callStatement
     * @throws IOException
     * @throws CompilationException
     */
    void argumentsList() throws IOException, CompilationException {
        myGenerate.commenceNonterminal("ArgumentList");
        acceptTerminal(Token.identifier);

        while(nextToken.symbol == Token.identifier || nextToken.symbol == Token.commaSymbol){
            acceptTerminal(nextToken.symbol); //if look ahead is either identifier or a comma, accept else throw an error
        }
        myGenerate.finishNonterminal("ArgumentList");
    }

    /**
     * Assignment statement method used by __
     * @throws IOException
     * @throws CompilationException
     */
    void assignmentStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("AssignmentStatement");

            acceptTerminal(Token.identifier);
            acceptTerminal(Token.becomesSymbol);

            if (nextToken.symbol == Token.stringConstant) {
                acceptTerminal(Token.stringConstant);
            } else {
                expressionStatement();
            }
            myGenerate.finishNonterminal("AssignmentStatement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <ASSIGNMENT STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Expression statement used by the assignment statement.
     * @throws IOException
     * @throws CompilationException
     */
    void expressionStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("Expression");
            term();//want to call term before anything else

        while(nextToken.symbol == Token.minusSymbol || nextToken.symbol  == Token.plusSymbol){
            acceptTerminal(nextToken.symbol);
            term();
        }
            myGenerate.finishNonterminal("Expression");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <EXPRESSION> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * While Statement used for teh grammar
     * @throws IOException
     * @throws CompilationException
     */
    void whileStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("WhileStatement");
            acceptTerminal(Token.whileSymbol);

            conditionStatement();//call the condition method

            acceptTerminal(Token.loopSymbol);//start loop

            getStatementList();//go to statement list, check to see if lookahead matches that

            acceptTerminal(Token.endSymbol);//end symbol
            acceptTerminal(Token.loopSymbol);//loop symbol

            myGenerate.finishNonterminal("While Statement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <WHILE STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Condition Statement
     * @throws IOException
     * @throws CompilationException
     */
    void conditionStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("Condition");

            acceptTerminal(Token.identifier);
            conditionalOperatorStatement();//go to conditional operator method

            switch (nextToken.symbol) {//if next token is either a number, string or an identifier, accept, else error
                case Token.numberConstant:
                    acceptTerminal(Token.numberConstant);
                    break;
                case Token.stringConstant:
                    acceptTerminal(Token.stringConstant);
                    break;
                case Token.identifier:
                    acceptTerminal(Token.identifier);
                    break;
                default:
                    myGenerate.reportError(nextToken,
                            "Error:[File:\"" + filename + "\"] [On line:" + nextToken.lineNumber + "]" +
                                    "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                    " Expecting: In Condition -> " +
                                    " (" + Token.getName(Token.numberConstant) +
                                    " ," + Token.getName(Token.stringConstant) + ")"
                    );
            }
            myGenerate.finishNonterminal("Condition");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <CONDITION STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Conditional Operator method used for condition statement
     * @throws IOException
     * @throws CompilationException
     */
    void conditionalOperatorStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("ConditionalOperator");

            switch (nextToken.symbol) {//if next token matches < , > , = , <=, >=, !=, then accept, else error
                case Token.notEqualSymbol:
                    acceptTerminal(Token.notEqualSymbol);
                    break;
                case Token.lessThanSymbol:
                    acceptTerminal(Token.lessThanSymbol);
                    break;
                case Token.lessEqualSymbol:
                    acceptTerminal(Token.lessEqualSymbol);
                    break;
                case Token.equalSymbol:
                    acceptTerminal(Token.equalSymbol);
                    break;
                case Token.greaterEqualSymbol:
                    acceptTerminal(Token.greaterEqualSymbol);
                    break;
                case Token.greaterThanSymbol:
                    acceptTerminal(Token.greaterThanSymbol);
                    break;

                default:
                    myGenerate.reportError(nextToken,
                            "ERROR:[File:\"" + filename + "\"] [On Line:" + nextToken.lineNumber + "]" +
                                    "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                    " Expecting: Conditional Operator ->" +
                                    " (" + Token.getName(Token.greaterEqualSymbol) +
                                    " ," + Token.getName(Token.equalSymbol) +
                                    " ," + Token.getName(Token.notEqualSymbol) +
                                    " ," + Token.getName(Token.lessThanSymbol) +
                                    " ," + Token.getName(Token.lessEqualSymbol) + ")"
                    );
            }
            myGenerate.finishNonterminal("Conditional Operator");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <CONDITIONAL OPERATOR> On Line Number " + nextToken.lineNumber, e);
        }

    }

    /**
     * The term method used in the _ method
     * @throws IOException
     * @throws CompilationException
     */
    void term() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("Term");
            factor();//go to the factor method

            if (nextToken.symbol == Token.timesSymbol) {//if next token is times or divide, keep recursing term
                acceptTerminal(Token.timesSymbol);
                term();
            } else if (nextToken.symbol == Token.divideSymbol) {
                acceptTerminal(Token.divideSymbol);
                term();
            }
            myGenerate.finishNonterminal("Term");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <TERM> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * Method of Factor used by Term
     * @throws IOException
     * @throws CompilationException
     */
    void factor() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("Factor");


            switch (nextToken.symbol) {//if token is a number, identifier or has a left/right parenthises, accept, else error
                case Token.numberConstant:
                    acceptTerminal(Token.numberConstant);
                    break;

                case Token.identifier:
                    acceptTerminal(Token.identifier);
                    break;

                case Token.leftParenthesis:
                    acceptTerminal(Token.leftParenthesis);
                    expressionStatement();
                    break;

                case Token.rightParenthesis:
                    acceptTerminal(Token.rightParenthesis);
                    break;

                default:
                    myGenerate.reportError(nextToken,
                            "Error:[File:\"" + filename + "\"] [On Line number :" + nextToken.lineNumber + "]" +
                                    "Found Token: " + nextToken.text + " (" + Token.getName(nextToken.symbol) + ")" +
                                    " Expecting: In Factor -> " +
                                    " (" + Token.getName(Token.identifier) +
                                    " ," + Token.getName(Token.numberConstant) +
                                    " ," + Token.getName(Token.leftParenthesis) + ")"
                    );
            }
            myGenerate.finishNonterminal("Factor");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <FACTOR> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * IF statement used by the statementList
     * @throws IOException
     * @throws CompilationException
     */
    void ifStatement() throws  IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("IfStatement");

            acceptTerminal(Token.ifSymbol);//if next token is if, thenaccept and go to condition
            conditionStatement();
            acceptTerminal(Token.thenSymbol);//if next token is then, then go to statement list,
            getStatementList();

            if (nextToken.symbol == Token.elseSymbol) {//if next token contains an else, go to statementlist
                getStatementList();
            }

            acceptTerminal(Token.endSymbol);
            acceptTerminal(Token.ifSymbol);


            myGenerate.finishNonterminal("IfStatement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <IF STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

    /**
     * For staement method
     * @throws IOException
     * @throws CompilationException
     */
    void forStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("ForStatement");
            acceptTerminal(Token.forSymbol);
            acceptTerminal(Token.leftParenthesis);
            assignmentStatement();
            acceptTerminal(Token.semicolonSymbol);

            conditionStatement();
            acceptTerminal(Token.semicolonSymbol);

            assignmentStatement();
            acceptTerminal(Token.rightParenthesis);

            acceptTerminal(Token.doSymbol);
            getStatementList();
            acceptTerminal(Token.endSymbol);
            acceptTerminal(Token.loopSymbol);

            myGenerate.finishNonterminal("ForStatement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <FOR STATEMENT> On Line Number " + nextToken.lineNumber,e);
        }
    }

    /**
     * The Until loop used by statementlist
     * @throws IOException
     * @throws CompilationException
     */
    void untilStatement() throws IOException, CompilationException {
        try {
            myGenerate.commenceNonterminal("UntilStatement");

            acceptTerminal(Token.untilSymbol);
            acceptTerminal(Token.doSymbol);
            getStatementList();
            acceptTerminal(Token.untilSymbol);
            conditionStatement();

            myGenerate.finishNonterminal("UntilStatement");
        }catch (CompilationException e){
            throw new CompilationException("Compilation Exception: Error Parsing In <UNTIL STATEMENT> On Line Number " + nextToken.lineNumber, e);
        }
    }

}
