/**
 * @Author Shehriyar Faisal
 * 33869774
 */
public class Generate extends AbstractGenerate {
    public long indent;

    @Override
    public void reportError(Token token, String explanatoryMessage) throws CompilationException {
        throw new CompilationException(explanatoryMessage);
    }
    @Override
    public void insertTerminal(Token token) {
        for (int i = 1; i < indent + 1; i++) {
            System.out.print("|\t");
        }
        super.insertTerminal(token);
    }
   @Override
    public void finishNonterminal(String name) {

        for(int i = 1; i<indent ; i++){
            System.out.print("|\t");
        }
        indent--;
        super.finishNonterminal(name);
    }
    @Override
    public void commenceNonterminal(String name) {
        for(int i = 1; i < indent+1; i++){
            System.out.print("|\t");
        }
        indent++;
        super.commenceNonterminal(name);
    }

}


